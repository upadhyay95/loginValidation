//
//  LoginModel.swift
//  LoginApp
//
//  Created by abhishek kumar upadhyay on 04/04/20.
//  Copyright © 2020 abhishek kumar upadhyay. All rights reserved.
//

import Foundation

struct LoginModel : Codable{
    var username : String = ""
    var password : String = ""
}
